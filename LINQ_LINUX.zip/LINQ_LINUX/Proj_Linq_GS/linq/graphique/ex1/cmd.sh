#! /bin/sh
gcc -o ex1 -I/usr/include/SDL2 ex1.c -lSDL2_image -lSDL2_ttf -lSDL2 -lpthread
