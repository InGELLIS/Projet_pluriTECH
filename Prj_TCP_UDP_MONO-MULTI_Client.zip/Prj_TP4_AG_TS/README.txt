# Makefile pour la compilation des fichiers serveur.c, serveur.h, client.c

Ce Makefile est utilisé pour compiler les fichiers source serveur.c, serveur.h et client.c afin de créer des exécutables pour différents scénarios.

## Structure du répertoire

Le répertoire contient les fichiers suivants 

- `Makefile`  Le fichier de configuration pour la compilation.
- `serveur.c`  Le code source du serveur.
- `serveur.h`  Le fichier d'en-tête pour le serveur.
- `client.c`  Le code source du client.
- `README.md`  Ce fichier README.

Les fichiers sources sont organisés dans la structure de répertoire suivante 

- `./code/MONO-client/TCP`  Fichiers source pour le client TCP du MONO-client.
- `./code/MONO-client/UDP`  Fichiers source pour le client UDP du MONO-client.
- `./code/MULTI-client/TCP`  Fichiers source pour le serveur TCP du MULTI-client.
- `./:code/MULTI-client/UDP`  Fichiers source pour le serveur UDP du MULTI-client.

## Utilisation

Assurez-vous d'avoir `gcc` installé sur votre système.

1. Modifiez les chemins des fichiers sources dans le Makefile pour correspondre à votre structure de répertoire.

2. Ouvrez un terminal et placez-vous dans le répertoire contenant le Makefile.

3. Exécutez la commande suivante pour compiler les fichiers 

    ```
    make all
    ```

    Cela générera les exécutables correspondants aux différents scénarios 

    - `bin/client_TCP`  Exécutable du client TCP du MONO-client.
    - `bin/serveur_TCP_mono-client`  Exécutable du serveur TCP du MONO-client.
    - `bin/client_UDP`  Exécutable du client UDP du MONO-client.
    - `bin/serveur_UDP_mono-client`  Exécutable du serveur UDP du MONO-client.
    - `bin/serveur_TCP_multi-client`  Exécutable du serveur TCP du MULTI-client.
    - `bin/serveur_UDP_multi-client`  Exécutable du serveur UDP du MULTI-client.

4. Pour nettoyer les fichiers générés, exécutez la commande suivante 

    ```
    make clean
    ```

    Cela supprimera le répertoire `bin` et tous les fichiers générés.

## Remarque

Assurez-vous d'avoir les droits nécessaires pour créer et supprimer des répertoires et fichiers dans le répertoire courant.

Pour toute question ou problème, n'hésitez pas à contacter l'auteur du projet (alexandre.gellis@gmail.com).

