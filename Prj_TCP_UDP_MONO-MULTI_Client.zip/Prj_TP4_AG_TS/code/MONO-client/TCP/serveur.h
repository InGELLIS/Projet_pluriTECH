#ifndef serveurh
#define serveurh
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

#define PORT 8080
#define MAX_CLIENTS 10
#define BUFFER_SIZE 1024

typedef struct Operation {
    char type_operation[10]; // Type d'opération (AJOUT ou RETRAIT)
    char date_operation[20]; // Date de l'opération (format texte)
    double montant_operation; // Montant de l'opération
} Operation;

typedef struct Compte {
    int id_client; // ID du client
    int id_compte; // ID du compte
    char password[32]; // Mot de passe du compte
    double solde; // Solde du compte
    Operation operations[10]; // Tableau des opérations effectuées (les 10 dernières)
    int nombre_operations; // Nombre total d'opérations effectuées
} Compte;

// Enregistre une opération dans le compte spécifié
void enregistrer_operation(Compte *compte, const char *type_operation, double montant);

// Recherche un compte à partir de l'ID du client, de l'ID du compte et du mot de passe
Compte *find_account_by_ID(int id_client, int id_compte, const char *password);

// Effectue l'opération d'ajout d'une somme au compte spécifié
int AJOUT(int id_client, int id_compte, const char *password, double somme);

// Effectue l'opération de retrait d'une somme du compte spécifié
int RETRAIT(int id_client, int id_compte, const char *password, double somme);

// Récupère le solde du compte spécifié
double SOLDE(int id_client, int id_compte, const char *password);

// Récupère les 10 dernières opérations effectuées sur le compte spécifié
char *OPERATIONS(int id_client, int id_compte, const char *password, char *buffer, size_t buffer_size);

#endif // serveurh