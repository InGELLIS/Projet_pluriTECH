/*
Le code suivant utilise TCP (Transmission Control Protocol) pour établir une connexion avec un serveur distant. 
Cela est indiqué par l'utilisation de la fonction socket(AF_INET, SOCK_STREAM, 0) qui crée un socket TCP.
*/
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define PORT 8080 // Port utilisé pour le proxy HTTP
//#define PORT 1234 // Port defaut
#define BUFFER_SIZE 1024

int main() {
    // Informations des requêtes :
    char AJOUT_Request[100] = "AJOUT <id_client> <id_compte> <password> <somme> \n";
    char RETRAIT_Request[100] = "RETRAIT <id_client> <id_compte> <password> <somme> \n";
    char SOLDE_Request[100] = "SOLDE <id_client> <id_compte> <password> \n";
    char OPERATIONS_Request[100] = "OPERATIONS <id_client> <id_compte> <password> \n";
    int client_fd;
    struct sockaddr_in serveur_addr;
    char buffer[BUFFER_SIZE];

    // Création du socket
    client_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (client_fd == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // Configuration de l'adresse du serveur
    serveur_addr.sin_family = AF_INET;
    serveur_addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK); // Utilisation de l'adresse locale
    serveur_addr.sin_port = htons(PORT);

    // Connexion au serveur
    if (connect(client_fd, (struct sockaddr *)&serveur_addr, sizeof(serveur_addr)) == -1) {
        perror("Etat de la connexion");
        exit(EXIT_FAILURE);
    }
 
    printf("Les requêtes disponibles sont :\n");
    printf("AJOUT d'argent : %s\n", AJOUT_Request);
    printf("RETRAIT d'argent : %s\n", RETRAIT_Request);
    printf("SOLDE du compte : %s\n", SOLDE_Request);
    printf("Afficher les 10 dernières opérations : %s\n", OPERATIONS_Request);

    while (1) {
        printf("\nEntrez votre requête ('Q' pour quitter) : ");
        fgets(buffer, BUFFER_SIZE, stdin);

        if (buffer[0] == 'Q' || buffer[0] == 'q') {
            break;
        }

        // Envoi de la requête au serveur
        send(client_fd, buffer, strlen(buffer), 0);

        // Réception de la réponse du serveur
        int len = read(client_fd, buffer, BUFFER_SIZE - 1);
        if (len == -1) {
            perror("read");
            break;
        }
        buffer[len] = '\0';
        printf("Réponse du serveur : %s\n", buffer);
    }

    close(client_fd);
    return 0;
}
