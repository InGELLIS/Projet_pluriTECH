/*
Le code suivant utilise UDP (User Datagram Protocol) pour établir une communication avec un serveur distant. 
Cela est indiqué par l'utilisation de la fonction socket(AF_INET, SOCK_DGRAM, 0) qui crée un socket UDP.
*/
#include "serveur.h"
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <time.h>


Compte comptes[] = {
    // {id_client, id_compte, password, solde, {{OPERATIONS}}, nombre_operations}
    {1, 1001, "password1", 10000.0, {{"", "", 0}}, 0},
    {2, 1002, "password2", 5000.0, {{"", "", 0}}, 0},
    {3, 1003, "password3", 2000.0, {{"", "", 0}}, 0},
    {4, 1004, "password4", 500.0, {{"", "", 0}}, 0}
};

int nombre_comptes = sizeof(comptes) / sizeof(comptes[0]);

// Enregistrer des opérations (lorsque le client ajoute ou retire de l'argent uniquement)
void enregistrer_operation(Compte *compte, const char *type_operation, double montant) {
    Operation *operation = &compte->operations[compte->nombre_operations % 10];
    strcpy(operation->type_operation, type_operation);
    time_t t = time(NULL);
    strftime(operation->date_operation, sizeof(operation->date_operation), "%Y-%m-%d %H:%M:%S", localtime(&t));
    operation->montant_operation = montant;
    compte->nombre_operations++;
}

// find_account_by_ID : Trouver un compte avec les informations suivantes :  id_client, id_compte et password
Compte *find_account_by_ID(int id_client, int id_compte, const char *password) {
    for (int i = 0; i < nombre_comptes; i++) {
        if (comptes[i].id_client == id_client && comptes[i].id_compte == id_compte &&
            strcmp(comptes[i].password, password) == 0) {
            return &comptes[i];
        }
    }
    return NULL;
}

// Ajouter une somme à un compte :
/* AJOUT <id_client id_compte password somme> permettra d'ajouter la somme sur le compte identifié par id_compte par le client id_client identifié avec password. */
int AJOUT(int id_client, int id_compte, const char *password, double somme) {
    Compte *compte = find_account_by_ID(id_client, id_compte, password);
    if (compte) {
        compte->solde += somme;
        // Enregistre l'opération
        enregistrer_operation(compte, "AJOUT", somme);
        return 1;
    }
    return 0;
}

/* RETRAIT <id_client id_compte password somme> permettra de retirer la somme sur le compte identifié par id_compte par le client id_client identifié avec password.*/
int RETRAIT(int id_client, int id_compte, const char *password, double somme) {
    Compte *compte = find_account_by_ID(id_client, id_compte, password);
    if (compte && compte->solde >= somme) {
        compte->solde -= somme;
        enregistrer_operation(compte, "RETRAIT", somme); // Enregistre l'opération
        return 1;
    }
    return 0;
}

/* SOLDE <id_client id_compte password> permettra d'obtenir le solde du compte identifié par id_compte par le client id_client identifié avec password. */
double SOLDE(int id_client, int id_compte, const char *password) {
    Compte *compte = find_account_by_ID(id_client, id_compte, password);
    if (compte) {
        return compte->solde;
    }
    return -1.0;
}

/* OPERATIONS <id_client id_compte password> permettra d'obtenir les 10 dernières opérations effectuée par le compte client */
char *OPERATIONS(int id_client, int id_compte, const char *password, char *buffer, size_t buffer_size) {
    Compte *compte = find_account_by_ID(id_client, id_compte, password);
    if (compte) {
        int start = (compte->nombre_operations > 10) ? compte->nombre_operations - 10 : 0;
        buffer[0] = '\0';
        for (int i = start; i < compte->nombre_operations; i++) {
            Operation *operation = &compte->operations[i % 10];
            char line[128];
            snprintf(line, sizeof(line), "%s %s %.2lf\n", operation->type_operation, operation->date_operation, operation->montant_operation);
            strncat(buffer, line, buffer_size - strlen(buffer) - 1);
        }
        return buffer;
    }
    return NULL;
   
}

 void afficher_informations_serveur(const char *informations) {
    printf("INFORMATIONS DU SERVEUR : %s\n", informations);
}

int main() {
    int serveur_fd; // Socket du serveur
    int client_fd=0; // Socket du client
    int addr_len; // Taille de la structure client_addr
    struct sockaddr_in serveur_addr, client_addr;
    char buffer[BUFFER_SIZE]; // Stocke les données reçues du client

    // Création du socket du serveur
    /* AF_INET : IPv4
       SOCK_DGRAM : Socket UDP
       0 : Protocole par défaut pour SOCK_DGRAM : Protocole TCP ??  */
    serveur_fd = socket(AF_INET, SOCK_DGRAM, 0);
    
    if (serveur_fd == -1) {
        // Affiche une erreur si la création du socket a échoué
        perror("socket");
        exit(EXIT_FAILURE);
    }
    
    // Configuration de l'adresse du serveur
    /* AF_INET : IPv4
       INADDR_ANY : Toutes les adresses IP disponibles (à déterminer)
        */
    serveur_addr.sin_family = AF_INET;
    serveur_addr.sin_addr.s_addr = INADDR_ANY;
    // Définition du port et conversion en format d'octets réseau (utilisation de htons : host-to-network short)
    serveur_addr.sin_port = htons(PORT);

    // Association de l'adresse du serveur (adresse et port) au socket
    if (bind(serveur_fd, (struct sockaddr *)&serveur_addr, sizeof(serveur_addr)) < 0) {
        perror("bind");
        exit(EXIT_FAILURE);
    }

    addr_len = sizeof(client_addr);
    
	printf("PORT DE COMMUNICATION : %d\n", PORT);
    	printf("EN ATTENTE DES REQUÊTES DES CLIENTS...\n");
    while (1) {

        int id_client, id_compte;
        char password[32];
        double somme;
        char response[BUFFER_SIZE];
        
      
        ssize_t bytes_read = recvfrom(serveur_fd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&client_addr, (socklen_t *)&addr_len);
        if (bytes_read <= 0) {
            break;
        }
        buffer[BUFFER_SIZE - 1] = '\0'; // Ajout du caractère de fin de chaîne

        if (sscanf(buffer, "AJOUT %d %d %s %lf", &id_client, &id_compte, password, &somme) == 4) {
            if (AJOUT(id_client, id_compte, password, somme)) {
                strcpy(response, "OK\n");
            } else {
                strcpy(response, "KO\n");
            }
            
        } else if (sscanf(buffer, "RETRAIT %d %d %s %lf", &id_client, &id_compte, password, &somme) == 4) {
            if (RETRAIT(id_client, id_compte, password, somme)) {
                strcpy(response, "OK\n");
            } else {
                strcpy(response, "KO\n");
            }
            
        } else if (sscanf(buffer, "SOLDE %d %d %s", &id_client, &id_compte, password) == 3) {
            double solde_compte = SOLDE(id_client, id_compte, password);
            if (solde_compte >= 0.0) { // Seulement si le compte n'est pas à découvert
                // snprintf : int snprintf(char *str, size_t size, const char *format, …);
                snprintf(response, BUFFER_SIZE, "LE SOLDE DE VOTRE COMPTE EST DE : %.2lf $", solde_compte);
            } else {
                strcpy(response, "KO\n");
            }
            
        } else if (sscanf(buffer, "OPERATIONS %d %d %s", &id_client, &id_compte, password) == 3) {
            char operations_buffer[BUFFER_SIZE];
            char *operations_result = OPERATIONS(id_client, id_compte, password, operations_buffer, BUFFER_SIZE);
            /* Retourne un pointeur vers un buffer contenant les 10 dernières opérations formatées. 
            Retourne NULL si la requête n'a pas pu être traitée et envoie "KO" au client. */
            if (operations_result) {
                snprintf(response, BUFFER_SIZE, "RÉSULTAT DES OPÉRATIONS :\n%s", operations_result);
            } else {
                strcpy(response, "KO\n");
            }
            
        } else {
            strcpy(response, "KO\n");
        }
        
// Envoi de la réponse au client
        sendto(serveur_fd, response, strlen(response), 0, (struct sockaddr *)&client_addr, addr_len);
     	  send(client_fd, buffer, strlen(buffer), 0);// --> Envoie la requête de retour
        
        // Affichage des informations envoyées par le serveur
        // afficher_informations_serveur(response);
        // afficher_informations_serveur(buffer);
    
    }
    
    return 0;
}

