/*
Le code suivant utilise UDP (User Datagram Protocol) pour établir une communication avec un serveur distant. 
Cela est indiqué par l'utilisation de la fonction socket(AF_INET, SOCK_DGRAM, 0) qui crée un socket UDP.
*/
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>

//#define PORT 8080 // Le port utilisé pour la communication.
#define PORT 1234 // Le port defaut
#define BUFFER_SIZE 1024 // La taille du tampon utilisé pour stocker les données reçues.
#define MAX_RETRIES 5 // Le nombre maximal de tentatives de communication avec le serveur.

int main() {
    // Informations des requêtes :
    char AJOUT_Request[100] = "AJOUT <id_client> <id_compte> <password> <somme> \n";
    char RETRAIT_Request[100] = "RETRAIT <id_client> <id_compte> <password> <somme> \n";
    char SOLDE_Request[100] = "SOLDE <id_client> <id_compte> <password> \n";
    char OPERATIONS_Request[100] = "OPERATIONS <id_client> <id_compte> <password> \n";

    // Création du socket (UDP -> SOCK_DGRAM)
    int client_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_fd == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // Configuration de l'adresse du serveur
    struct sockaddr_in serveur_addr;
    serveur_addr.sin_family = AF_INET;
    serveur_addr.sin_addr.s_addr = INADDR_ANY;
    serveur_addr.sin_port = htons(PORT);

    printf("Les requêtes disponibles sont :\n");
    printf("AJOUT d'argent : %s\n", AJOUT_Request);
    printf("RETRAIT d'argent : %s\n", RETRAIT_Request);
    printf("SOLDE du compte : %s\n", SOLDE_Request);
    printf("Afficher les 10 dernières opérations : %s\n", OPERATIONS_Request);
    
    char buffer[BUFFER_SIZE];

    while (1) {
        printf("\nEntrez votre requête ('Q' pour quitter) : ");
        fgets(buffer, BUFFER_SIZE, stdin);
        fflush(stdin);

        if (buffer[0] == 'Q' || buffer[0] == 'q') {
            break;
        }
    
        // Envoi de la requête au serveur
        socklen_t addr_len = sizeof(serveur_addr);

        int tries_qty = 0;
        int response_received = 0;
        
        while (tries_qty < MAX_RETRIES && !response_received) {
            // Envoi du paquet au serveur
            sendto(client_fd, buffer, strlen(buffer), 0, (struct sockaddr *)&serveur_addr, addr_len);

            // Utilisation de select() pour déterminer si le socket est prêt, réessaiera MAX_RETRIES si pas de réponse du serveur 
            fd_set read_fds;
            struct timeval timeout;
            int select_result;

            FD_ZERO(&read_fds);
            FD_SET(client_fd, &read_fds);
            timeout.tv_sec = tries_qty + 1; // timeout = try_qty + 1 seconde
            timeout.tv_usec = 0;

            select_result = select(client_fd + 1, &read_fds, NULL, NULL, &timeout); // Vérifie si le socket est prêt à recevoir des requêtes

            if (select_result > 0) { // Le socket est prêt : réception de la réponse du serveur
                int response_len = recvfrom(client_fd, buffer, BUFFER_SIZE, 0, (struct sockaddr *)&serveur_addr, &addr_len);
                if (response_len >= 1) {
                    buffer[response_len] = '\0';
                    printf("Réponse du serveur: %s\n", buffer);
                    response_received = 1;
                }

            } else if (select_result == 0) { // Le délai d'attente a expiré
                tries_qty++;
                printf("PAS DE COMMUNICATION, tentative %d...\r", tries_qty);
                fflush(stdout); // Vide le buffer stdout

            } else {
                perror("select");
                break;
            }
        }

        if (tries_qty == MAX_RETRIES) {
            printf("Aucun retour du serveur après %d tentatives.\n Relancer SERVEUR et/ou changer de PORT(port actuel : %d)\n", MAX_RETRIES, PORT);
        }
    }

    close(client_fd);
    return 0;
}
