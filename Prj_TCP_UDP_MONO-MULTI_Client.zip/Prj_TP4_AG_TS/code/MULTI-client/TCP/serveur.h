#ifndef serveurh
#define serveurh

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>

#define PORT 8080
#define MAX_CLIENTS 10
#define BUFFER_SIZE 1024

typedef struct Operation {
    char type_operation[10]; // Type d'opération (AJOUT, RETRAIT, etc.)
    char date_operation[20]; // Date de l'opération au format "AAAA-MM-JJ HH:MM:SS"
    double montant_operation; // Montant de l'opération
} Operation;

typedef struct Compte {
    int id_client; // ID du client
    int id_compte; // ID du compte
    char password[32]; // Mot de passe du compte
    double solde; // Solde du compte
    Operation operations[10]; // Tableau des 10 dernières opérations
    int nombre_operations; // Nombre d'opérations enregistrées dans le tableau
} Compte;

/* Routine de thread pour servir la connexion au client. */
void *pthread_routine(void *arg);

/* Enregistre une opération dans le compte donné. */
void enregistrer_operation(Compte *compte, const char *type_operation, double montant);

/* Recherche un compte en utilisant l'ID du client et l'ID du compte. */
Compte *find_account_by_ID(int id_client, int id_compte, const char *password);

/* Effectue une opération d'AJOUT d'argent dans le compte donné. */
int AJOUT(int id_client, int id_compte, const char *password, double somme);

/* Effectue une opération de RETRAIT d'argent du compte donné. */
int RETRAIT(int id_client, int id_compte, const char *password, double somme);

/* Récupère le solde du compte donné. */
double SOLDE(int id_client, int id_compte, const char *password);

/* Récupère les 10 dernières opérations du compte donné et les stocke dans le buffer fourni. */
char *OPERATIONS(int id_client, int id_compte, const char *password, char *buffer, size_t buffer_size);

#endif // serveurh

