/*
Le code suivant utilise TCP (Transmission Control Protocol) pour établir une connexion avec un serveur distant. 
Cela est indiqué par l'utilisation de la fonction socket(AF_INET, SOCK_STREAM, 0) qui crée un socket TCP.
*/
#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>

#define PORT 8080 // Port utilisé pour le proxy HTTP
#define BUFFER_SIZE 1024

int main() {
    // Informations des requêtes :
    char AJOUT_Request[100] = "AJOUT <id_client> <id_compte> <password> <somme> \n";
    char RETRAIT_Request[100] = "RETRAIT <id_client> <id_compte> <password> <somme> \n";
    char SOLDE_Request[100] = "SOLDE <id_client> <id_compte> <password> \n";
    char OPERATIONS_Request[100] = "OPERATIONS <id_client> <id_compte> <password> \n";

    // Création du socket (UDP -> SOCK_DGRAM)
    int client_fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (client_fd == -1) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // Configuration de l'adresse du serveur
    struct sockaddr_in serveur_addr;
    serveur_addr.sin_family = AF_INET;
    serveur_addr.sin_addr.s_addr = INADDR_ANY;
    serveur_addr.sin_port = htons(PORT);

    printf("Les requêtes disponibles sont :\n");
    printf("AJOUT d'argent : %s\n", AJOUT_Request);
    printf("RETRAIT d'argent : %s\n", RETRAIT_Request);
    printf("SOLDE du compte : %s\n", SOLDE_Request);
    printf("Afficher les 10 dernières opérations : %s\n", OPERATIONS_Request);
    
    char buffer[BUFFER_SIZE];
    while (1) {
        printf("\nEntrez votre requête ('Q' pour quitter) : ");
        fgets(buffer, BUFFER_SIZE, stdin);
        
        if (buffer[0] == 'Q' || buffer[0] == 'q') {
            break;
        }

        // Envoi de la requête au serveur
        sendto(client_fd, buffer, strlen(buffer), 0, (struct sockaddr*)&serveur_addr, sizeof(serveur_addr));

        // Réception de la réponse du serveur
        int len = recvfrom(client_fd, buffer, BUFFER_SIZE, 0, NULL, NULL);
        buffer[len] = '\0';
        printf("Réponse du serveur : %s\n", buffer);
    }

    close(client_fd);
    return 0;
}
