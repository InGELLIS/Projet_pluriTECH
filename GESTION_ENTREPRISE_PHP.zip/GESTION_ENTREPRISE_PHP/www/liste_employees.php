<?php
session_start();
// Paramètres de connexion à la base de données
$servername = "localhost:3306";
$username = "root";
$password = "";
$dbname = "gestionentreprise";

// Création de la connexion
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Requête SQL pour récupérer tous les employés
$sql = "SELECT Nom, Prenom FROM Employes ORDER BY Nom, Prenom";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Liste des Employés</title>
    <style>
        table, th, td {
            border: 1px solid black;
            border-collapse: collapse;
        }
    </style>
</head>
<header>
<link rel="stylesheet" type="text/css" href="liste.css">
</header>
<body>
        <!-- Bouton pour ajouter un employé en redirigeant vers la page d'ajout -->
        <button onclick="window.location.href='../Home.php'"> HOME</button>
    
<?php 
// Vérifiez si les valeurs sont enregistrées en session
if (isset($_SESSION['nom']) && isset($_SESSION['prenom'])) {
    $nom = $_SESSION['nom'];
    $prenom = $_SESSION['prenom'];
    
    echo "<p>L'employé " . htmlspecialchars($nom) . " " . htmlspecialchars($prenom) . " a été bien inscrit.</p>";
} else {
    echo "<p>Erreur: L'employé n'est pas inscrit.</p>";
}
?>

<h2>Liste des Employés</h2>

<?php if ($result->num_rows > 0): ?>
    <table>
        <tr>
            <th>Nom</th>
            <th>Prénom</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo htmlspecialchars($row['Nom']); ?></td>
                <td><?php echo htmlspecialchars($row['Prenom']); ?></td>
            </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>Aucun employé trouvé.</p>
<?php endif; ?>

<?php
// Fermeture de la connexion
$conn->close();
?>

</body>
</html>
