<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Your Website Title</title>
<link rel="stylesheet" href="Home_style.css">
<script src="jsHome.js" defer></script>
</head>
<body>
<div class="content-wrap">
<header>
    <nav>
        <div class="logo">LOGO</div>
        <ul>
            <li><a href="Home.php">HOME</a></li>
            <li><a href="about.php">ABOUT</a></li>
            <li><a href="Team.php">TEAM</a></li>
        </ul>
    </nav>
    <div class="header-content">
        <h1>Gestion d'Entreprise</h1>
        <p>Alexandre GELLIS</p>
    </div>
</header>
<main class="main-content">
<div class="call-to-action">

    <section class="cta ">
        <div class="content">
            <h2>Our Employees</h2>
            <button onclick="window.location.href='inscription_employee.php'">Employee Registration</button>
        </div>
    </section>  

    <section class="cta">
        <div class="content">
            <h2>Our Clients</h2>
            <button onclick="window.location.href='display_clients.php'">Client List</button>
        </div>
    </section>

    <section class="cta">
        <div class="content">
            <h2>Commands</h2>
            <button onclick="window.location.href='display_commandes.php'">Details</button>
        </div>
    </section>


</div>
</main>

</div>

<footer>
    <p>&copy; 2025 Your Website Name</p>
</footer>

</body>
</html>
