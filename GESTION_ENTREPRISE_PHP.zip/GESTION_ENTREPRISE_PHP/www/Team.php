<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Your Website Title</title>
<link rel="stylesheet" href="Home_style.css">
<script src="jsHome.js" defer></script>
</head>
<body>
<div class="content-wrap">
<header>
    <nav>
        <div class="logo">LOGO</div>
        <ul>
            <li><a href="Home.php">HOME</a></li>
            <li><a href="about.php">ABOUT</a></li>
            <li><a href="Team.php">TEAM</a></li>
        </ul>
    </nav>
    <div class="header-content">
        <h1>TEAM</h1>
        <p>Projet GBD</p>
    </div>
</header>
<main class="main-content">
<div class="call-to-action">
    <div class="header-content">
        <h1>MEMBERS</h1>
        <p>GELLIS Alexandre</p>
    </div>
    </section>


</div>
</main>

</div>

<footer>
    <p>&copy; 2023 Your Website Name</p>
</footer>

</body>
</html>
