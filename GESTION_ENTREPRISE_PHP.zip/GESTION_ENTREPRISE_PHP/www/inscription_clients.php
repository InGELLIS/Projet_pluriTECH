<?php
session_start(); // Commence ou reprend une session

// Définition des variables et initialisation avec des valeurs vides
$nomErr = $prenomErr = $emailErr = $adresseErr = $numeroAdresseErr = $telephoneErr = "";
$nom = $prenom = $email = $adresse = $numeroAdresse = $telephone = "";

// Fonction pour nettoyer les données d'entrée
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Validation du formulaire après soumission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["nom"])) {
        $nomErr = "Le nom est requis";
    } else {
        $nom = test_input($_POST["nom"]);
        // Vérifie si le nom contient uniquement des lettres et des espaces
        if (!preg_match("/^[a-zA-Z ]*$/", $nom)) {
            $nomErr = "Seulement les lettres et les espaces blancs sont autorisés";
        }
    }

    if (empty($_POST["prenom"])) {
        $prenomErr = "Le prénom est requis";
    } else {
        $prenom = test_input($_POST["prenom"]);
        // Vérifie si le prénom contient uniquement des lettres et des espaces
        if (!preg_match("/^[a-zA-Z ]*$/", $prenom)) {
            $prenomErr = "Seulement les lettres et les espaces blancs sont autorisés";
        }
    }

    if (empty($_POST["email"])) {
        $emailErr = "L'email est requis";
    } else {
        $email = test_input($_POST["email"]);
        // Vérifie si l'email est bien formaté
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = "Format d'email invalide";
        }
    }

    if (empty($_POST["adresse"])) {
        $adresseErr = "L'adresse est requise";
    } else {
        $adresse = test_input($_POST["adresse"]);
    }

    if (empty($_POST["numeroAdresse"])) {
        $numeroAdresseErr = "Le numéro de l'adresse est requis";
    } else {
        $numeroAdresse = test_input($_POST["numeroAdresse"]);
    }

    if (empty($_POST["telephone"])) {
        $telephoneErr = "Le numéro de téléphone est requis";
    } else {
        $telephone = test_input($_POST["telephone"]);
    }

    // Enregistrement des données en session si le formulaire est valide
    if (empty($nomErr) && empty($prenomErr) && empty($emailErr)) {
        $_SESSION['nom'] = $nom;
        $_SESSION['prenom'] = $prenom;
        $_SESSION['email'] = $email;

        // Paramètres de connexion à la base de données
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "gestionentreprise";

        // Créez une connexion
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Vérifiez la connexion
        if ($conn->connect_error) {
            die("Échec de la connexion : " . $conn->connect_error);
        }

        // Préparez la requête d'insertion
        $stmt = $conn->prepare("INSERT INTO clients (nom, prenom, email, adresse, numero_adresse, numero_telephone) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $nom, $prenom, $email, $adresse, $numeroAdresse, $telephone);

        if ($stmt->execute()) {
            // Redirection vers la page display_client.php
            header("Location: display_clients.php");
            exit();
        } else {
            // Gérez l'erreur ici
            echo "Erreur : " . $stmt->error;
        }

        // Fermez la déclaration et la connexion
        $stmt->close();
        $conn->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        .error {color: #FF0000;}
    </style>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<header>
    <div class="home-button">
        <a href="Home.php">Retour à l'accueil</a>
    </div>
</header>
<body>
<div class="wrapper fadeInDown">
    <div id="formContent">
        <p><span class="error">* champs requis.</span></p>
        <div class="fadeIn first">
            <img src="user.png" id="icon" alt="User Icon" class="round-image" />
        </div>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            <input type="text" id="nom" name="nom" class="fadeIn second" placeholder="Nom" value="<?php echo $nom; ?>">
            <span class="error">* <?php echo $nomErr;?></span>
            <input type="text" id="prenom" name="prenom" class="fadeIn third" placeholder="Prénom" value="<?php echo $prenom; ?>">
            <span class="error">* <?php echo $prenomErr;?></span>
            <input type="email" id="email" name="email" class="fadeIn" placeholder="Email" value="<?php echo $email; ?>">
            <span class="error">* <?php echo $emailErr;?></span>
            <input type="text" id="adresse" name="adresse" class="fadeIn" placeholder="Adresse" value="<?php echo $adresse; ?>">
            <span class="error">* <?php echo $adresseErr;?></span>
            <input type="text" id="numeroAdresse" name="numeroAdresse" class="fadeIn" placeholder="Numéro de l'adresse" value="<?php echo $numeroAdresse; ?>">
            <span class="error">* <?php echo $numeroAdresseErr;?></span>
            <input type="text" id="telephone" name="telephone" class="fadeIn" placeholder="Numéro de téléphone" value="<?php echo $telephone; ?>">
            <span class="error">* <?php echo $telephoneErr;?></span>
            <input type="submit" name="submit" value="S'inscrire" class="fadeIn fourth">
        </form>
    </div>
</div>
</body>
</html>
