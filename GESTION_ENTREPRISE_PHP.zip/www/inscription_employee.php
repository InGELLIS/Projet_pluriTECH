<?php
session_start(); // Commence ou reprend une session

// Définition des variables et initialisation avec des valeurs vides
$nomErr = $prenomErr = "";
$nom = $prenom = "";
$ville = $codePostal = $pays = "";
$villeErr = $codePostalErr = $paysErr = "";

// Fonction pour nettoyer les données d'entrée
function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Validation du formulaire après soumission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["nom"])) {
        $nomErr = "Le nom est requis";
    } else {
        $nom = test_input($_POST["nom"]);
        // vérifie si le nom contient uniquement des lettres et des espaces
        if (!preg_match("/^[a-zA-Z ]*$/", $nom)) {
            $nomErr = "Seulement les lettres et les espaces blancs sont autorisés";
        }
    }
    
    if (empty($_POST["prenom"])) {
        $prenomErr = "Le prénom est requis";
    } else {
        $prenom = test_input($_POST["prenom"]);
        // vérifie si le prénom contient uniquement des lettres et des espaces
        if (!preg_match("/^[a-zA-Z ]*$/", $prenom)) {
            $prenomErr = "Seulement les lettres et les espaces blancs sont autorisés";
        }
    }

    if (empty($_POST["ville"])) {
        $villeErr = "La ville est requise";
    } else {
        $ville = test_input($_POST["ville"]);
        // Additional validation if needed
    }

    if (empty($_POST["codePostal"])) {
        $codePostalErr = "Le code postal est requis";
    } else {
        $codePostal = test_input($_POST["codePostal"]);
        // Additional validation if needed
    }

    if (empty($_POST["pays"])) {
        $paysErr = "Le pays est requis";
    } else {
        $pays = test_input($_POST["pays"]);
        // Additional validation if needed
    }



    // Enregistrement des données en session si le formulaire est valide
    if (empty($nomErr) && empty($prenomErr)) {
        $_SESSION['nom'] = $nom;
        $_SESSION['prenom'] = $prenom;

         // Si aucune erreur n'est trouvée, procédez à l'insertion dans la base de données
         // Paramètres de connexion à la base de données
         // Paramètres de connexion à la base de données
        $servername = "localhost:3307";
        $username = "root";
        $password = "";
        $dbname = "gestionentreprise";


        // Créez une connexion
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Vérifiez la connexion
        if ($conn->connect_error) {
            die("Échec de la connexion : " . $conn->connect_error);
        }

        // Préparez la requête d'insertion
        $stmt = $conn->prepare("INSERT INTO Employes (Nom, Prenom) VALUES (?, ?)");
        $stmt->bind_param("ss", $nom, $prenom);

        if ($stmt->execute()) {
            // Redirection vers la page de la liste des employés
            header("Location: liste_employees.php");
            exit();
        } else {
            // Gérez l'erreur ici
            echo "Erreur : " . $stmt->error;
        }
        
        // Fermez la déclaration et la connexion
        $stmt->close();
        $conn->close();
        
    }
    

}
?>

<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <style>
        .error {color: #FF0000;}
    </style>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<header>
    <div class="home-button">
                <a href="Home.php">Retour à l'accueil</a> <!-- Adjust the href value to your actual homepage URL -->
            </div>
</header>

<body>

<div class="wrapper fadeInDown">
 <div id="formContent">

<p><span class="error">* champs requis.</span></p>

    <div class="fadeIn first">
      <img src="user.png" id="icon" alt="User Icon" class="round-image" />
    </div>

<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

        <input type="text" id="nom" name="nom" class="fadeIn second" placeholder="Nom" value="<?php echo $nom; ?>">
        <span class="error">* <?php echo $nomErr;?></span>   
        <input type="text" id="prenom" name="prenom" class="fadeIn third" placeholder="Prenom" value="<?php echo $prenom; ?>">
        <span class="error">* <?php echo $prenomErr;?></span>

        <input type="text" id="ville" name="ville" class="fadeIn" placeholder="Ville" value="<?php echo $ville; ?>">
        <span class="error">* <?php echo $villeErr;?></span>

        <input type="text" id="codePostal" name="codePostal" class="fadeIn" placeholder="Code Postal" value="<?php echo $codePostal; ?>">
        <span class="error">* <?php echo $codePostalErr;?></span>

        <input type="text" id="pays" name="pays" class="fadeIn" placeholder="Pays" value="<?php echo $pays; ?>">
        <span class="error">* <?php echo $paysErr;?></span>

        <input type="submit" name="submit" value="S'inscrire" class="fadeIn fourth">
</div>
</div>

</body>

</html>




   
    
