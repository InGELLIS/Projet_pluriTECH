SELECT * FROM Clients;
SELECT Nom, Prenom, Email FROM Clients;
SELECT * FROM Commandes WHERE Total > 100.00;
SELECT * FROM Commandes WHERE Total > 100.00 AND Date_Commande >= '2023-01-01';
SELECT Clients.Nom, Clients.Prenom, Commandes.Total, Commandes.Date_Commande
FROM Clients
JOIN Commandes ON Clients.ID_Client = Commandes.ID_Client; 
SELECT Clients.Nom, Commandes.Date_Commande, Commandes.Total
FROM Clients
JOIN Commandes ON Clients.ID_Client = Commandes.ID_Client
ORDER BY Commandes.Date_Commande DESC;
SELECT Clients.Nom, Clients.Prenom, Commandes.Date_Commande, Produits.Nom_Produit, Details_Commandes.Quantite
FROM Commandes
JOIN Clients ON Commandes.ID_Client = Clients.ID_Client
JOIN Details_Commandes ON Commandes.ID_Commande = Details_Commandes.ID_Commande
JOIN Produits ON Details_Commandes.ID_Produit = Produits.ID_Produit;
SELECT SUM(Total) AS TotalVentes FROM Commandes;
SELECT ID_Client, SUM(Total) AS TotalVentesParClient
FROM Commandes
GROUP BY ID_Client;
SELECT *
FROM Clients
WHERE ID_Client IN (SELECT ID_Client FROM Commandes WHERE Total > 100.00);
SELECT * FROM Clients WHERE Nom LIKE 'liza%';
SELECT * FROM Clients LIMIT 2 OFFSET 5; 







