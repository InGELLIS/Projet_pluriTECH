function startChat() {
    // Implement chat functionality or redirect to chat page
    alert("Chat functionality not implemented yet.");
  }


