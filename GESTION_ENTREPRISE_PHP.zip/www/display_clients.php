<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>

<head>
    <title>Clients</title>
    <link rel="stylesheet" href="../styles_PROJET/display_table.css">
    <meta charset="UTF-8">
</head>

<body>

    <h1>Clients</h1>
    <!-- Bouton pour ajouter un employé en redirigeant vers la page d'ajout -->
    <button onclick="window.location.href='../Home.php'">HOME</button>
    <?php

    /* Fonction pour interroger la base de données et retourner les résultatsg */
    function query_database($q)
        {
                $conn = new mysqli("127.0.0.1", "root", "", "gestionentreprise");
                if ($conn->connect_error) die($conn->connect_error);

                $query  = $q;
                $result = $conn->query($query);
                if (!$result)
                        die ("Database access failed: " . $conn->error);

                $rows = $result->num_rows;

                $table_1 = array();

                for ($j = 0 ; $j < $rows ; ++$j)
                {
                        $result->data_seek($j);
                        $row = $result->fetch_row();

                        array_push($table_1,$row);
                }

                $result->close();
                $conn->close();

                return array($rows, $table_1);
        }
        /*  Fonction pour insérer une ligne dans la base de données  */
        function insertRow($table_name, $col, $data)
        {
            $conn = new mysqli("localhost:3307", "root", "", "gestionentreprise");
            if ($conn->connect_error)
                die($conn->connect_error);
        
            $query = "INSERT INTO $table_name ($col) VALUES ($data)";
            $result = $conn->query($query);
            if (!$result)
                die("" . $conn->error);
        } 

        ?>    
    <table>
        <tr>
            <th>Numéro du client </th>
            <th>Nom</th>
            <th>Prénom</th>
            <th>Adresse</th>
            <th>Numéro de l'adresse</th>
            <th>Email</th>
            <th>Numéro de téléphone</th>
        </tr>
        <?php
        $clients = query_database("SELECT * FROM clients");
        for ($i = 0; $i < $clients[0]; $i++) {
            echo "<tr>";
            for ($j = 0; $j < 7; $j++) {
                echo "<td>" . $clients[1][$i][$j] . "</td>";
            }
            echo "</tr>";
        }
        ?>
    </table>
</body>

</html>