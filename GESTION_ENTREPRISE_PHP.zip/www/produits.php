<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01//EN">
<html>

<head>
    <title>produits</title>
    <link rel="stylesheet" href="../styles_PROJET/display_table.css">
    <meta charset="UTF-8">
</head>

<body>

    <h1>produits</h1>
    <!-- Bouton pour ajouter un employé en redirigeant vers la page d'ajout -->
    <button onclick="window.location.href='../Home.php'">HOME</button>
    <?php

    /* Fonction pour interroger la base de données et retourner les résultatsg */
    function query_database($q)
        {
                $conn = new mysqli("127.0.0.1", "root", "", "gestionentreprise");
                if ($conn->connect_error) die($conn->connect_error);

                $query  = $q;
                $result = $conn->query($query);
                if (!$result)
                        die ("Database access failed: " . $conn->error);

                $rows = $result->num_rows;

                $table_1 = array();

                for ($j = 0 ; $j < $rows ; ++$j)
                {
                        $result->data_seek($j);
                        $row = $result->fetch_row();

                        array_push($table_1,$row);
                }

                $result->close();
                $conn->close();

                return array($rows, $table_1);
        }
        /*  Fonction pour insérer une ligne dans la base de données  */
        function insertRow($table_name, $col, $data)
        {
            $conn = new mysqli("localhost:3306", "root", "", "gestionentreprise");
            if ($conn->connect_error)
                die($conn->connect_error);
        
            $query = "INSERT INTO $table_name ($col) VALUES ($data)";
            $result = $conn->query($query);
            if (!$result)
                die("" . $conn->error);
        } 

        ?>    
    <table>
        <tr>
            <th>Numéro du produit </th>
            <th>Nom du produit</th>
            <th>Description</th>
            <th>Prix unitaire</th>
        </tr>
        <?php
        $produits = query_database("SELECT * FROM produits");
        for ($i = 0; $i < $produits[0]; $i++) {
            echo "<tr>";
            for ($j = 0; $j < 4; $j++) {
                echo "<td>" . $produits[1][$i][$j] . "</td>";
            }
            echo "</tr>";
        }
        ?>
    </table>
</body>

</html>